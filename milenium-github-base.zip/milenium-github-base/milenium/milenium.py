import sys
import os
from parser import MileniumParser

def print_help():
    print("""
==================================================
           🌟 MILENIUM PROGRAMMING LANGUAGE 🌟
==================================================
Kullanım:
  milenium run <dosya.mln>    : Belirtilen Milenium dosyasını çalıştırır.
  milenium build <dosya.mln>  : Milenium kodunu Python (.py) koduna çevirir.
  milenium help               : Bu yardım menüsünü gösterir.
  milenium version            : Sürüm bilgisini gösterir.
==================================================
""")

def main():
    if len(sys.argv) < 2:
        print_help()
        return

    command = sys.argv[1].lower()

    if command == "run":
        if len(sys.argv) < 3:
            print("[Milenium CLI Hata]: Çalıştırılacak dosya adını belirtmedin! Örn: milenium run main.mln")
            return
        
        target_file = sys.argv[2]
        parser = MileniumParser()
        parser.compile_and_run(target_file)

    elif command == "build":
        if len(sys.argv) < 3:
            print("[Milenium CLI Hata]: Dönüştürülecek dosya adını belirtmedin! Örn: milenium build main.mln")
            return
        
        target_file = sys.argv[2]
        output_file = target_file.replace(".mln", ".py")
        parser = MileniumParser()
        parser.compile_to_py(target_file, output_py_filepath=output_file)
        print(f"[Milenium CLI]: Başarıyla dönüştürüldü -> {output_file}")

    elif command in ["version", "-v", "--version"]:
        print("Milenium Language v1.0.0 (Core Engine)")

    else:
        print(f"[Milenium CLI Hata]: Bilinmeyen komut '{command}'. Yardım için: milenium help")

if __name__ == "__main__":
    main()