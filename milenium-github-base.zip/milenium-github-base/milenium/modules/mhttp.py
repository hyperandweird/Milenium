import urllib.request
import json

class MileniumHTTP:
    def get(self, url):
        try:
            req = urllib.request.urlopen(url)
            return req.read().decode('utf-8')
        except Exception as e:
            return f"Error: {e}"

    def get_json(self, url):
        res = self.get(url)
        try:
            return json.loads(res)
        except:
            return {}

# Parser'ın import edebilmesi için instance (nesne) tanımı:
mhttp = MileniumHTTP()