class MileniumColor:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RESET = '\033[0m'

    def print(self, text, color="RESET"):
        c = getattr(self, color.upper(), self.RESET)
        print(f"{c}{text}{self.RESET}")

mcolor = MileniumColor()