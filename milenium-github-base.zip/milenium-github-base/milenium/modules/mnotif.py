import platform, os

class MileniumNotif:
    def send(self, title, message):
        sys_name = platform.system()
        if sys_name == "Windows":
            try:
                from win10toast import ToastNotifier
                ToastNotifier().show_toast(title, message, duration=5)
            except:
                os.system(f'msg * "{title}: {message}"')
        elif sys_name == "Linux":
            os.system(f'notify-send "{title}" "{message}"')

mnotif = MileniumNotif()