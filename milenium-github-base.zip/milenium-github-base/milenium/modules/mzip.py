import zipfile
import os

class MileniumZip:
    def compress(self, folder, output_zip):
        with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(folder):
                for file in files:
                    zipf.write(os.path.join(root, file), 
                               os.path.relpath(os.path.join(root, file), folder))

    def extract(self, zip_file, extract_to):
        with zipfile.ZipFile(zip_file, 'r') as zipf:
            zipf.extractall(extract_to)

# Parser'ın içe aktarabilmesi için şart olan nesne tanımı:
mzip = MileniumZip()