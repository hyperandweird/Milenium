import csv

class MileniumCSV:
    def read(self, path):
        with open(path, mode='r', encoding='utf-8') as f:
            return list(csv.reader(f))
    def write(self, path, rows):
        with open(path, mode='w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerows(rows)

mcsv = MileniumCSV()