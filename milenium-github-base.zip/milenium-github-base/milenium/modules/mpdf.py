import os

class MileniumPDF:
    def __init__(self):
        self.content = []
        self.title = "Milenium Dokümanı"

    def new_document(self, title="Milenium Dokümanı"):
        """Yeni bir PDF doküman taslağı açar."""
        self.title = title
        self.content = [f"# {title}\n", "=" * 40 + "\n"]

    def add_heading(self, text):
        """Dokümana başlık ekler."""
        self.content.append(f"\n## {text}\n")

    def add_paragraph(self, text):
        """Dokümana paragraf metni ekler."""
        self.content.append(f"{text}\n")

    def add_line(self):
        """Ayraç çizgi ekler."""
        self.content.append("-" * 30 + "\n")

    def export_html_pdf(self, filename="cikti.html"):
        """İçeriği şık bir HTML/PDF raporu olarak kaydeder."""
        body = "".join([f"<p>{line}</p>" for line in self.content])
        html = f"""
        <html>
        <head><style>body {{ font-family: Arial; padding: 40px; line-height: 1.6; }}</style></head>
        <body>{body}</body>
        </html>
        """
        with open(filename, "w", encoding="utf-8") as f:
            f.write(html)
        print(f"[Milenium PDF]: Rapor {filename} olarak kaydedildi.")

mpdf = MileniumPDF()