import json
import re
import urllib.request

class MileniumAI:
    def __init__(self):
        # Basit duygu analizi kelime havuzu
        self.pos_words = ["harika", "süper", "iyi", "güzel", "muhteşem", "efsane", "başarılı", "bayıldım", "sevdim", "kolay"]
        self.neg_words = ["kötü", "berbat", "rezalet", "hata", "çöp", "zor", "çirkin", "sevmedim", "bozuk"]

    def analyze_sentiment(self, text: str) -> str:
        """Metnin duygu durumunu analiz eder (Olumlu, Olumsuz, Nötr)."""
        text_lower = text.lower()
        pos_score = sum(1 for w in self.pos_words if w in text_lower)
        neg_score = sum(1 for w in self.neg_words if w in text_lower)

        if pos_score > neg_score:
            return "Olumlu 😊"
        elif neg_score > pos_score:
            return "Olumsuz 😞"
        else:
            return "Nötr 😐"

    def summarize(self, text: str, sentence_count: int = 2) -> str:
        """Uzun bir metni ilk önemli cümlelerine ayırarak özetler."""
        sentences = [s.strip() for s in re.split(r'[.!?]+', text) if s.strip()]
        if len(sentences) <= sentence_count:
            return text
        return ". ".join(sentences[:sentence_count]) + "."

    def chat_local(self, prompt: str, model: str = "llama3") -> str:
        """
        Bilgisayarda Ollama çalışıyorsa yerel AI modeline soru sorar.
        """
        url = "http://localhost:11434/api/generate"
        payload = json.dumps({
            "model": model,
            "prompt": prompt,
            "stream": False
        }).encode("utf-8")
        
        req = urllib.request.Request(url, data=payload, headers={'Content-Type': 'application/json'})
        
        try:
            with urllib.request.urlopen(req, timeout=10) as response:
                res = json.loads(response.read().decode())
                return res.get("response", "Yanıt alınamadı.")
        except Exception:
            return "[mai]: Yerel Ollama AI sunucusuna ulaşılamadı."

# Tek instance
mai = MileniumAI()