import math

class MileniumMath:
    def sqrt(self, n):
        return math.sqrt(n)

    def pow(self, x, y):
        return math.pow(x, y)

    def factorial(self, n):
        return math.factorial(n)

    def is_even(self, n):
        return n % 2 == 0

    def is_odd(self, n):
        return n % 2 != 0

    def pi(self):
        return math.pi

# Parser'ın içe aktarabilmesi için şart olan nesne tanımı:
mmath = MileniumMath()