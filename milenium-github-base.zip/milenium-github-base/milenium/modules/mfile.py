import os
import shutil

class MileniumFile:
    def read(self, path): 
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    def write(self, path, content): 
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    def exists(self, path):
        return os.path.exists(path)

    def delete(self, path): 
        if os.path.exists(path):
            os.remove(path)

# En alt satırdaki bu değişken parser için şart:
mfile = MileniumFile()