import random, string

class MileniumRandom:
    def number(self, min_val, max_val): return random.randint(min_val, max_val)
    def choice(self, lst): return random.choice(lst)
    def password(self, length=12):
        chars = string.ascii_letters + string.digits + "!@#$%^&*"
        return ''.join(random.choice(chars) for _ in range(length))

mrandom = MileniumRandom()