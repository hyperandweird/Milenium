import os

class MileniumImage:
    def info(self, image_path):
        if os.path.exists(image_path):
            size = os.path.getsize(image_path)
            return f"Image: {image_path}, Size: {size} bytes"
        return "Resim bulunamadı."

mimg = MileniumImage()