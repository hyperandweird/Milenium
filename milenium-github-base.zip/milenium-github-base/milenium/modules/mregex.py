import re

class MileniumRegex:
    def is_email(self, email):
        return bool(re.match(r"^[\w\.-]+@[\w\.-]+\.\w+$", email))
    def find_all(self, pattern, text):
        return re.findall(pattern, text)

mregex = MileniumRegex()