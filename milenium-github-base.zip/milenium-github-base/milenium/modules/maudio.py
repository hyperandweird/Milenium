import os
import re
import sys

class MileniumParser:
    def __init__(self):
        # Milenium başlatıldığında tüm modülleri otomatik içeri aktaran ön yükleme listesi
        self.preloads = [
            "import sys",
            "import os",
            "from modules.mwindow import milenium_gui as milenium",
            "from modules.mengine import mengine",
            "from modules.mpdf import mpdf",
            "from modules.mdb import mdb",
            "from modules import maudio",
            "from modules import mfile",
            "from modules import mnet",
            "from modules import msystem",
            "from modules import mmath",
            ""
        ]

    def parse_line(self, line: str) -> str:
        """
        Tek bir Milenium satırını okur ve Python karşılığına çevirir.
        """
        stripped = line.strip()
        
        # Boş satırları ve yorum satırlarını olduğu gibi bırak
        if not stripped or stripped.startswith("#"):
            return line

        # 1. Otomatik olarak yüklü olan modül importlarını pasifleştir
        if stripped.startswith("import m"):
            return f"# {stripped} (Milenium Core tarafından otomatik yüklendi)"

        # 2. Parametre isimlerindeki ':' işaretlerini Python'ın anlayacağı '=' işaretine çevir
        # Örn: milenium.window(name:"App", width:800) -> milenium.window(name="App", width=800)
        # Not: URL ve tırnak içindeki metinleri bozmaması için regex anahtar kelimeleri süzmektedir.
        parsed_line = re.sub(r'(\b\w+)\s*:\s*', r'\1=', line)

        return parsed_line

    def parse_code(self, mln_code: str) -> str:
        """
        Tüm Milenium kodunu okuyup çalıştırılabilir Python koduna dönüştürür.
        """
        lines = mln_code.splitlines()
        compiled_lines = list(self.preloads)

        for line in lines:
            compiled_lines.append(self.parse_line(line))

        return "\n".join(compiled_lines)

    def compile_to_py(self, mln_filepath: str, output_py_filepath: str = None) -> str:
        """
        .mln dosyasını okur ve isteğe bağlı olarak .py olarak kaydeder.
        """
        if not os.path.exists(mln_filepath):
            raise FileNotFoundError(f"[Milenium Hata]: Dosya bulunamadı -> {mln_filepath}")

        with open(mln_filepath, "r", encoding="utf-8") as f:
            mln_code = f.read()

        python_code = self.parse_code(mln_code)

        if output_py_filepath:
            with open(output_py_filepath, "w", encoding="utf-8") as f:
                f.write(python_code)

        return python_code

    def compile_and_run(self, mln_filepath: str):
        """
        .mln dosyasını Python koduna dönüştürür ve hafızada (exec ile) çalıştırır.
        """
        try:
            python_code = self.compile_to_py(mln_filepath)
            global_scope = {}
            exec(python_code, global_scope)
        except Exception as e:
            print(f"\n[Milenium Çalışma Zamanı Hatası]:")
            print(f"-> {e}\n")


if __name__ == "__main__":
    # Konsoldan çalıştırmak için: python parser.py main.mln
    parser = MileniumParser()
    target_file = sys.argv[1] if len(sys.argv) > 1 else "main.mln"
    
    if os.path.exists(target_file):
        parser.compile_and_run(target_file)
    else:
        print(f"[Milenium]: Çalıştırılacak '{target_file}' dosyası bulunamadı.")

# Auto-generated instance for Milenium Parser
maudio = MileniumParser()
