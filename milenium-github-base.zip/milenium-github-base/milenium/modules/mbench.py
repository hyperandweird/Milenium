import time

class MileniumBench:
    def __init__(self): self.start_time = 0
    def start(self): self.start_time = time.time()
    def stop(self):
        elapsed = time.time() - self.start_time
        print(f"[BENCHMARK]: Geçen Süre: {elapsed:.4f} saniye")
        return elapsed

mbench = MileniumBench()