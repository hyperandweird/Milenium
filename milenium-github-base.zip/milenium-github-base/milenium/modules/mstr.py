import re

class MileniumString:
    def reverse(self, text): return text[::-1]
    def slugify(self, text): return re.sub(r'[^\w\s-]', '', text).strip().lower().replace(' ', '-')
    def word_count(self, text): return len(text.split())

mstr = MileniumString()