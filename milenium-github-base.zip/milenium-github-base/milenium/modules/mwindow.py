import tkinter as tk
from tkinter import messagebox

class MainWindow:
    """Milenium için Tkinter tabanlı pencereleri yöneten sınıf."""

    def __init__(self, title="Milenium Window", size="700x500", bg_color="#1e1e2e", fg_color="#cdd6f4"):
        self.root = tk.Tk()
        self.root.title(title)
        self.root.geometry(size)
        self.root.configure(bg=bg_color)
        
        self.bg_color = bg_color
        self.fg_color = fg_color

    def add_label(self, text, font_size=14):
        """Pencereye yazı etiketi ekler."""
        label = tk.Label(
            self.root, 
            text=text, 
            font=("Segoe UI", font_size, "bold"), 
            bg=self.bg_color, 
            fg=self.fg_color
        )
        label.pack(pady=12)
        return label

    def add_button(self, text, command=None):
        """Pencereye buton ekler."""
        btn = tk.Button(
            self.root, 
            text=text, 
            command=command, 
            font=("Segoe UI", 11, "bold"),
            bg="#89b4fa", 
            fg="#11111b",
            activebackground="#b4befe",
            activeforeground="#11111b",
            padx=20, 
            pady=8,
            bd=0,
            cursor="hand2"
        )
        btn.pack(pady=10)
        return btn

    def add_entry(self, placeholder=""):
        """Pencereye metin giriş kutusu ekler."""
        entry = tk.Entry(
            self.root, 
            font=("Segoe UI", 12),
            bg="#313244", 
            fg=self.fg_color,
            insertbackground=self.fg_color,
            bd=1,
            relief="solid"
        )
        if placeholder:
            entry.insert(0, placeholder)
        entry.pack(pady=8, ipady=6, ipadx=10)
        return entry

    def show_message(self, title, message):
        """Ekrana bilgi iletişim kutusu çıkartır."""
        messagebox.showinfo(title, message)

    def show(self):
        """Pencereyi ekranda gösterir ve döngüyü başlatır."""
        self.root.mainloop()