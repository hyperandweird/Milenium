import sqlite3

class MileniumDB:
    def __init__(self):
        self.conn = None
        self.cursor = None

    def connect(self, db_name="milenium_data.db"):
        """Veritabanına bağlanır veya yenisini oluşturur."""
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()

    def create_table(self, table_name, fields_str):
        """Tek satırda tablo açar. Örn: create_table("oyuncular", "isim TEXT, skor INT")"""
        query = f"CREATE TABLE IF NOT EXISTS {table_name} ({fields_str})"
        self.cursor.execute(query)
        self.conn.commit()

    def insert(self, table_name, values_tuple):
        """Veri ekler."""
        placeholders = ",".join(["?"] * len(values_tuple))
        query = f"INSERT INTO {table_name} VALUES ({placeholders})"
        self.cursor.execute(query, values_tuple)
        self.conn.commit()

    def fetch_all(self, table_name):
        """Tablodaki tüm verileri listeler."""
        self.cursor.execute(f"SELECT * FROM {table_name}")
        return self.cursor.fetchall()

mdb = MileniumDB()