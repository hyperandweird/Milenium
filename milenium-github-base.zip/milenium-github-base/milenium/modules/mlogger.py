import os
import datetime
import subprocess
import platform

# Terminal renk kodları (ANSI)
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

class MileniumLogger:
    def __init__(self):
        self.log_file = "milenium_system.log"

    def _write_log(self, level, message):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] [{level}] {message}\n"
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(log_entry)

    def info(self, message):
        """Yeşil renkli Bilgi Logu"""
        print(f"{Colors.OKGREEN}[INFO]{Colors.ENDC} {message}")
        self._write_log("INFO", message)

    def warn(self, message):
        """Sarı renkli Uyarı Logu"""
        print(f"{Colors.WARNING}[WARN]{Colors.ENDC} {message}")
        self._write_log("WARN", message)

    def error(self, message):
        """Kırmızı renkli Hata Logu"""
        print(f"{Colors.FAIL}[ERROR]{Colors.ENDC} {message}")
        self._write_log("ERROR", message)

    def show_milenium_logs(self):
        """Milenium'un genel sistem log sayfasını/çıktısını açar."""
        print(f"\n{Colors.HEADER}{Colors.BOLD}=== 📜 MILENIUM SISTEM LOG SAYFASI ==={Colors.ENDC}\n")
        if os.path.exists(self.log_file):
            with open(self.log_file, "r", encoding="utf-8") as f:
                logs = f.readlines()
                if logs:
                    for line in logs[-20:]:  # Son 20 log satırını göster
                        print(line.strip())
                else:
                    print(f"{Colors.OKBLUE}Henüz kaydedilmiş log bulunmuyor.{Colors.ENDC}")
        else:
            print(f"{Colors.OKBLUE}Henüz bir log dosyası oluşturulmadı.{Colors.ENDC}")
        print(f"\n{Colors.HEADER}{Colors.BOLD}====================================={Colors.ENDC}\n")

    def show_process_logs(self, process_name):
        """Belirtilen bir işlemin (process) sistemdeki durum ve logunu gösterir."""
        print(f"\n{Colors.OKBLUE}{Colors.BOLD}=== 🔍 PROCESS LOGS: '{process_name}' ==={Colors.ENDC}\n")
        
        system = platform.system()
        try:
            if system == "Windows":
                # Windows tasklist komutu ile filtreleme
                output = subprocess.check_output(f'tasklist /FI "IMAGENAME eq {process_name}*"', shell=True, text=True)
            else:
                # Linux/macOS ps komutu ile filtreleme
                output = subprocess.check_output(f'ps aux | grep {process_name}', shell=True, text=True)
            
            print(output)
            self._write_log("PROCESS_INSPECT", f"Checked status for process: {process_name}")
        except Exception as e:
            print(f"{Colors.FAIL}İşlem logları alınırken hata oluştu: {e}{Colors.ENDC}")

# Tekil instance ve doğrudan çağrı fonksiyonları
mlogger = MileniumLogger()

def log_milenium():
    """mlogger 'milenium' çağrısı için"""
    mlogger.show_milenium_logs()

def log_process(process_name):
    """mlogger process 'process_name' çağrısı için"""
    mlogger.show_process_logs(process_name)

# Auto-generated instance for Milenium Parser
mlogger = Colors()
