import platform
import os

class MileniumSystem:
    def os_name(self):
        return platform.system()

    def os_release(self):
        return platform.release()

    def user(self):
        try:
            return os.getlogin()
        except Exception:
            return os.getenv("USERNAME", os.getenv("USER", "Kullanici"))

    def cpu_usage(self):
        try:
            import psutil
            return f"%{psutil.cpu_percent()}"
        except ImportError:
            return "psutil yuklu degil (pip install psutil)"

    def ram_usage(self):
        try:
            import psutil
            return f"%{psutil.virtual_memory().percent}"
        except ImportError:
            return "psutil yuklu degil (pip install psutil)"

# Parser'ın içe aktarabilmesi için ŞART olan nesne tanımı:
msystem = MileniumSystem()