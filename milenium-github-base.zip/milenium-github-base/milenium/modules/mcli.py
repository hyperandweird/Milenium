class MileniumCLI:
    def progress_bar(self, iteration, total, prefix='', suffix='', length=30):
        percent = f"{100 * (iteration / float(total)):.1f}"
        filled = int(length * iteration // total)
        bar = '█' * filled + '-' * (length - filled)
        print(f'\r{prefix} |{bar}| %{percent} {suffix}', end='\r')
        if iteration == total: print()

mcli = MileniumCLI()