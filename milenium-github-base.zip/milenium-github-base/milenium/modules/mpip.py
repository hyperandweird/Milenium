import os
import zipfile
import json

class MileniumPIP:
    def __init__(self):
        self.modules_dir = "modules"
        self.registry_file = "installed_mpips.json"
        self.registry = self.load_registry()

    def load_registry(self):
        if os.path.exists(self.registry_file):
            try:
                with open(self.registry_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except:
                return {}
        return {}

    def save_registry(self):
        with open(self.registry_file, "w", encoding="utf-8") as f:
            json.dump(self.registry, f, indent=4)

    def load_package(self, mpip_path):
        if not os.path.exists(mpip_path):
            print(f"[mpip Error]: Package file '{mpip_path}' not found!")
            return

        print(f"[mpip]: Installing '{mpip_path}'...")
        try:
            with zipfile.ZipFile(mpip_path, 'r') as zipf:
                zipf.extractall(self.modules_dir)
                file_list = zipf.namelist()

            pkg_name = os.path.basename(mpip_path)
            self.registry[pkg_name] = {
                "files": file_list,
                "source": mpip_path
            }
            self.save_registry()
            print(f"[mpip Success]: '{pkg_name}' successfully installed and activated! 🎉")
        except Exception as e:
            print(f"[mpip Error]: Failed to install package: {e}")

    def list_packages(self):
        print("\n=== 📦 INSTALLED MILENIUM MPIP PACKAGES ===")
        if not self.registry:
            print("No .mpip packages installed yet.")
        else:
            for pkg, info in self.registry.items():
                print(f" ✨ {pkg} -> Contents: {', '.join(info['files'])}")
        print("===========================================\n")

mpip = MileniumPIP()