import socket
import subprocess
import platform

class MileniumNet:
    def get_ip(self):
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"

    def ping(self, host):
        param = '-n' if platform.system().lower() == 'windows' else '-c'
        try:
            res = subprocess.call(['ping', param, '1', host], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return res == 0
        except Exception:
            return False

# Parser'ın içe aktarabilmesi için şart olan nesne tanımı:
mnet = MileniumNet()