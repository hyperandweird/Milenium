import time, datetime

class MileniumTime:
    def now(self): return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    def sleep(self, seconds): time.sleep(seconds)
    def timestamp(self): return int(time.time())

mtime = MileniumTime()