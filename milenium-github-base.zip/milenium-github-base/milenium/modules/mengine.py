import pygame
import sys

class MileniumEngine:
    def __init__(self):
        self.screen = None
        self.clock = pygame.time.Clock()
        self.is_running = False
        self.fps = 60
        self.background_color = (30, 30, 30)

    def init_game(self, title="Milenium Game", width=800, height=600):
        """Oyun penceresini ve sistemini başlatır."""
        pygame.init()
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption(title)
        self.is_running = True

    def clear(self, color=(30, 30, 30)):
        """Ekranı temizler."""
        self.background_color = color
        self.screen.fill(color)

    def draw_box(self, x, y, width, height, color=(255, 0, 0)):
        """Ekran üzerine kutu/karakter çizer."""
        pygame.draw.rect(self.screen, color, (x, y, width, height))

    def draw_text(self, text, x, y, size=24, color=(255, 255, 255)):
        """Oyun içine yazı yazar."""
        font = pygame.font.SysFont("Arial", size)
        surface = font.render(text, True, color)
        self.screen.blit(surface, (x, y))

    def is_key_down(self, key_name):
        """Klavye tuşuna basılıp basılmadığını kontrol eder (Örn: 'space', 'left', 'w')."""
        keys = pygame.key.get_pressed()
        key_map = {
            "space": pygame.K_SPACE, "left": pygame.K_LEFT, "right": pygame.K_RIGHT,
            "up": pygame.K_UP, "down": pygame.K_DOWN, "w": pygame.K_w,
            "a": pygame.K_a, "s": pygame.K_s, "d": pygame.K_d
        }
        target = key_map.get(key_name.lower())
        return keys[target] if target else False

    def update(self):
        """Kareyi günceller ve olayları (events) dinler."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.is_running = False
                pygame.quit()
                sys.exit()
        
        pygame.display.flip()
        self.clock.tick(self.fps)

mengine = MileniumEngine()