import json, os

class MileniumConfig:
    def __init__(self, filename="config.json"):
        self.filename = filename
        self.data = self.load()

    def load(self):
        if os.path.exists(self.filename):
            with open(self.filename, "r", encoding="utf-8") as f: return json.load(f)
        return {}

    def set(self, key, value):
        self.data[key] = value
        with open(self.filename, "w", encoding="utf-8") as f: json.dump(self.data, f, indent=4)

    def get(self, key, default=None):
        return self.data.get(key, default)

mconfig = MileniumConfig()