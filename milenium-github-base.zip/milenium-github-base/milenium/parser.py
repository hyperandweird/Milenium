import sys
import io
import os

# Terminal encoding fix for characters
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

class MileniumParser:
    def __init__(self):
        pass

    def compile_and_run(self, file_path):
        print(f"[Milenium]: Running '{file_path}'...")
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                code = f.read()
            
            # Basit komut çalıştırma (Örn: print("Merhaba"))
            for line in code.splitlines():
                line = line.strip()
                if line.startswith("print(") and line.endswith(")"):
                    content = line[6:-1].strip()
                    if (content.startswith('"') and content.endswith('"')) or (content.startswith("'") and content.endswith("'")):
                        print(content[1:-1])
                    else:
                        print(content)
        except Exception as e:
            print(f"[Milenium Error]: {e}")

    def build(self, file_path):
        print(f"[Milenium]: Building '{file_path}'...")

if __name__ == "__main__":
    parser = MileniumParser()
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        # 1. MPIP Commands
        if command == "mpip":
            from modules.mpip import mpip
            sub_command = sys.argv[2] if len(sys.argv) > 2 else ""
            
            if sub_command == "load":
                target_mpip = sys.argv[3] if len(sys.argv) > 3 else ""
                mpip.load_package(target_mpip)
            elif sub_command == "list":
                mpip.list_packages()
            else:
                print("Usage:")
                print("  milenium mpip load <package.mpip>")
                print("  milenium mpip list")

        # 2. RUN Command
        elif command == "run":
            target_file = sys.argv[2] if len(sys.argv) > 2 else ""
            if os.path.exists(target_file):
                parser.compile_and_run(target_file)
            else:
                print(f"[Milenium Error]: File '{target_file}' not found.")

        # 3. BUILD Command
        elif command == "build":
            target_file = sys.argv[2] if len(sys.argv) > 2 else ""
            if os.path.exists(target_file):
                parser.build(target_file)
            else:
                print(f"[Milenium Error]: File '{target_file}' not found.")

        # 4. Quick Execution (e.g. milenium main.mln)
        elif os.path.exists(command):
            parser.compile_and_run(command)
        else:
            print(f"[Milenium Error]: Unknown command or file: '{command}'")
    else:
        print("Milenium v1.0 - Usage: milenium <run/build/mpip> <file>")