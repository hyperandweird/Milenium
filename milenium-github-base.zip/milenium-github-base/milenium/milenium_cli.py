import sys
import io
import os
import json
import zipfile
import importlib
import traceback
import builtins

# Terminal encoding fix for character compatibility
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# Ensure current directory and modules directory are in Python sys.path
current_dir = os.getcwd()
modules_dir = os.path.join(current_dir, "modules")

if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

if os.path.exists(modules_dir) and modules_dir not in sys.path:
    sys.path.insert(0, modules_dir)


class MileniumParser:
    """Core execution engine for Milenium scripts with detailed error reporting."""

    def __init__(self):
        pass

    def compile_and_run(self, file_path):
        print(f"🚀 [Milenium Engine]: '{file_path}' çalıştırılıyor...\n")
        
        if not os.path.exists(file_path):
            print(f"❌ [MILENIUM HATASI]: '{file_path}' adında bir dosya bulunamadı!")
            print(f"💡 İpucu: Dosya adını doğru yazdığından emin ol.\n")
            return

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                code_content = f.read()

            # Dynamic module loader function
            def import_module(module_path):
                try:
                    short_name = module_path.split('.')[-1]
                    
                    # Try importing by relative module path or short module name
                    try:
                        imported_mod = importlib.import_module(module_path)
                    except ModuleNotFoundError:
                        imported_mod = importlib.import_module(short_name)
                    
                    # Inject directly into scope and global builtins
                    exec_scope[short_name] = imported_mod
                    setattr(builtins, short_name, imported_mod)
                    
                    print(f"✅ [Milenium Loader]: '{module_path}' modülü başarıyla yüklendi.")
                    return imported_mod

                except Exception as e:
                    print(f"\n❌ [MİLENİUM MODÜL YÜKLEME HATASI]: '{module_path}' yüklenemedi!")
                    print(f"   Hata Detayı: {e}")
                    print(f"   Kontrol Et: 'modules/' klasöründe '{module_path.split('.')[-1]}.py' var mı?\n")
                    raise e

            # Global scope for Milenium script
            exec_scope = {
                "__name__": "__main__",
                "__file__": file_path,
                "import_module": import_module,
            }

            # Execute the MLN script
            exec(code_content, exec_scope)
            print(f"\n✨ [Milenium]: Program çalışmayı başarıyla tamamladı.")

        except SyntaxError as syn_err:
            print(f"\n❌ [MİLENİUM SÖZDİZİM (SYNTAX) HATASI]:")
            print(f"   Dosya : {syn_err.filename}")
            print(f"   Satır  : {syn_err.lineno}")
            print(f"   Kod    : {syn_err.text.strip() if syn_err.text else ''}")
            print(f"   Açıklama: {syn_err.msg}\n")

        except NameError as name_err:
            print(f"\n❌ [MİLENİUM İSİM (NAME) HATASI]:")
            print(f"   Açıklama: {name_err}")
            print(f"   İpucu: Çağırmaya çalıştığın modül veya değişken tanımlı değil.\n")

        except AttributeError as attr_err:
            print(f"\n❌ [MİLENİUM ÖZELLİK (ATTRIBUTE) HATASI]:")
            print(f"   Açıklama: {attr_err}")
            print(f"   İpucu: Modül içinde çağırdığın sınıf/fonksiyon (ör. MainWindow) mevcut mu?\n")

        except Exception as e:
            print(f"\n❌ [MİLENİUM ÇALIŞMA ZAMANI HATASI]: {type(e).__name__}: {e}")
            print("--- DETAYLI HATA İZLEME (TRACEBACK) ---")
            traceback.print_exc()
            print("---------------------------------------\n")

    def build(self, file_path):
        print(f"[Milenium Engine]: Building script '{file_path}'...")
        if not os.path.exists(file_path):
            print(f"[Milenium Error]: Script file '{file_path}' not found.")
            return
        print(f"[Milenium Success]: Build completed for '{file_path}'.")


class MileniumPIP:
    """Package manager system for loading and tracking .mpip extensions."""

    def __init__(self):
        self.modules_dir = "modules"
        self.registry_file = "installed_mpips.json"
        if not os.path.exists(self.modules_dir):
            os.makedirs(self.modules_dir)
        self.registry = self.load_registry()

    def load_registry(self):
        if os.path.exists(self.registry_file):
            try:
                with open(self.registry_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def save_registry(self):
        try:
            with open(self.registry_file, "w", encoding="utf-8") as f:
                json.dump(self.registry, f, indent=4)
        except Exception as e:
            print(f"[mpip Error]: Failed to save registry: {e}")

    def load_package(self, mpip_path):
        if not os.path.exists(mpip_path):
            print(f"[mpip Error]: Package file '{mpip_path}' not found!")
            return

        print(f"[mpip]: Installing package '{mpip_path}'...")
        try:
            with zipfile.ZipFile(mpip_path, "r") as zipf:
                zipf.extractall(self.modules_dir)
                file_list = zipf.namelist()

            pkg_name = os.path.basename(mpip_path)
            self.registry[pkg_name] = {
                "files": file_list,
                "source": mpip_path,
            }
            self.save_registry()
            print(
                f"[mpip Success]: Package '{pkg_name}' successfully installed and activated! 🎉"
            )
        except Exception as e:
            print(f"[mpip Error]: Failed to install package: {e}")

    def list_packages(self):
        print("\n=== 📦 INSTALLED MILENIUM MPIP PACKAGES ===")
        if not self.registry:
            print("No .mpip packages installed yet.")
        else:
            for pkg, info in self.registry.items():
                print(f" ✨ {pkg} -> Contents: {', '.join(info['files'])}")
        print("===========================================\n")


class MileniumCLI:
    """Command Line Interface router handling all operational parameters."""

    def __init__(self):
        self.parser = MileniumParser()
        self.mpip = MileniumPIP()

    def create_package(self, target_path):
        if not os.path.exists(target_path):
            print(f"[Milenium Error]: Path '{target_path}' not found!")
            return

        base_name = os.path.basename(os.path.normpath(target_path))
        package_name, _ = os.path.splitext(base_name)
        output_mpip = f"{package_name}.mpip"

        print(
            f"[mpip Builder]: Creating package '{output_mpip}' from '{target_path}'..."
        )

        try:
            with zipfile.ZipFile(output_mpip, "w", zipfile.ZIP_DEFLATED) as zipf:
                if os.path.isfile(target_path):
                    zipf.write(target_path, arcname=os.path.basename(target_path))
                elif os.path.isdir(target_path):
                    for root, dirs, files in os.walk(target_path):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(
                                file_path, start=os.path.dirname(target_path)
                            )
                            zipf.write(file_path, arcname=arcname)

            print(
                f"[mpip Success]: Successfully created package '{output_mpip}'! 🎉"
            )
            print(f"You can load it using: milenium mpip load \"{output_mpip}\"")
        except Exception as e:
            print(f"[mpip Error]: Failed to create .mpip package: {e}")

    def run_cli(self):
        if len(sys.argv) > 1:
            command = sys.argv[1]

            if command == "mpip":
                sub_command = sys.argv[2] if len(sys.argv) > 2 else ""
                if sub_command == "load":
                    target_mpip = sys.argv[3] if len(sys.argv) > 3 else ""
                    self.mpip.load_package(target_mpip)
                elif sub_command == "list":
                    self.mpip.list_packages()
                else:
                    print("Usage:")
                    print("  milenium mpip load <package.mpip>")
                    print("  milenium mpip list")

            elif command == "create_mpip":
                target_path = sys.argv[2] if len(sys.argv) > 2 else ""
                if target_path:
                    self.create_package(target_path)
                else:
                    target_path_input = input(
                        "Enter the path of the Python file or folder to package: "
                    ).strip()
                    if target_path_input:
                        self.create_package(target_path_input)
                    else:
                        print(
                            "[Milenium Error]: No path specified for package creation."
                        )

            elif command == "run":
                target_file = sys.argv[2] if len(sys.argv) > 2 else ""
                self.parser.compile_and_run(target_file)

            elif command == "build":
                target_file = sys.argv[2] if len(sys.argv) > 2 else ""
                self.parser.build(target_file)

            elif os.path.exists(command):
                self.parser.compile_and_run(command)
            else:
                print(f"[Milenium Error]: Unknown command or file: '{command}'")
        else:
            print("Milenium v1.0 Ecosystem - Usage:")
            print("  milenium run <file.mln>")
            print("  milenium build <file.mln>")
            print("  milenium create_mpip <file_or_folder>")
            print("  milenium mpip load <package.mpip>")
            print("  milenium mpip list")


if __name__ == "__main__":
    cli = MileniumCLI()
    cli.run_cli()