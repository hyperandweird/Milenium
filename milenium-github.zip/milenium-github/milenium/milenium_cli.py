import sys
import io
import os
import zipfile

# Terminal encoding fix for characters
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

class MileniumCLI:
    def __init__(self):
        pass

    def create_package(self, target_path):
        if not os.path.exists(target_path):
            print(f"[Milenium Error]: Path '{target_path}' not found!")
            return

        base_name = os.path.basename(os.path.normpath(target_path))
        package_name, _ = os.path.splitext(base_name)
        output_mpip = f"{package_name}.mpip"

        print(f"[mpip Builder]: Creating '{output_mpip}' from '{target_path}'...")

        try:
            with zipfile.ZipFile(output_mpip, 'w', zipfile.ZIP_DEFLATED) as zipf:
                if os.path.isfile(target_path):
                    zipf.write(target_path, arcname=os.path.basename(target_path))
                elif os.path.isdir(target_path):
                    for root, dirs, files in os.walk(target_path):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, start=os.path.dirname(target_path))
                            zipf.write(file_path, arcname=arcname)

            print(f"[mpip Success]: Successfully created '{output_mpip}'! 🎉")
            print(f"You can load it using: milenium mpip load \"{output_mpip}\"")
        except Exception as e:
            print(f"[mpip Error]: Failed to create .mpip package: {e}")

    def run_cli(self):
        if len(sys.argv) > 1:
            command = sys.argv[1]
            
            # 1. MPIP Commands
            if command == "mpip":
                from modules.mpip import mpip
                sub_command = sys.argv[2] if len(sys.argv) > 2 else ""
                
                if sub_command == "load":
                    target_mpip = sys.argv[3] if len(sys.argv) > 3 else ""
                    mpip.load_package(target_mpip)
                elif sub_command == "list":
                    mpip.list_packages()
                else:
                    print("Usage:")
                    print("  milenium mpip load <package.mpip>")
                    print("  milenium mpip list")

            # 2. CREATE_MPIP Command
            elif command == "create_mpip":
                target_path = sys.argv[2] if len(sys.argv) > 2 else ""
                if target_path:
                    self.create_package(target_path)
                else:
                    target_path_input = input("Enter the path of the Python file or folder to package: ").strip()
                    if target_path_input:
                        self.create_package(target_path_input)
                    else:
                        print("[Milenium Error]: No path specified for package creation.")

            # 3. RUN Command
            elif command == "run":
                target_file = sys.argv[2] if len(sys.argv) > 2 else ""
                if os.path.exists(target_file):
                    from parser import MileniumParser
                    parser = MileniumParser()
                    parser.compile_and_run(target_file)
                else:
                    print(f"[Milenium Error]: File '{target_file}' not found.")

            # 4. BUILD Command
            elif command == "build":
                target_file = sys.argv[2] if len(sys.argv) > 2 else ""
                if os.path.exists(target_file):
                    from parser import MileniumParser
                    parser = MileniumParser()
                    parser.build(target_file)
                else:
                    print(f"[Milenium Error]: File '{target_file}' not found.")

            # 5. Quick Execution (e.g. milenium main.mln)
            elif os.path.exists(command):
                from parser import MileniumParser
                parser = MileniumParser()
                parser.compile_and_run(command)
            else:
                print(f"[Milenium Error]: Unknown command or file: '{command}'")
        else:
            print("Milenium v1.0 - Usage:")
            print("  milenium run <file.mln>")
            print("  milenium create_mpip <file_or_folder>")
            print("  milenium mpip load <package.mpip>")
            print("  milenium mpip list")

if __name__ == "__main__":
    cli = MileniumCLI()
    cli.run_cli()