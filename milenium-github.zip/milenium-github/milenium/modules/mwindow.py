import tkinter as tk
from tkinter import messagebox

class MileniumWindow:
    def __init__(self):
        self.root = None

    def window(self, name="Milenium App", width=800, height=600, bg="#1e1e1e"):
        """Tek satırda pencere oluşturur."""
        self.root = tk.Tk()
        self.root.title(name)
        self.root.geometry(f"{width}x{height}")
        self.root.configure(bg=bg)

    def button(self, text="Tıkla", action=None, bg="#007acc", fg="white"):
        """Tek satırda stilize buton ekler."""
        btn = tk.Button(self.root, text=text, command=action, bg=bg, fg=fg, font=("Arial", 11, "bold"))
        # Hata buradaydı: px=10 yerine padx=10 yapıyoruz
        btn.pack(pady=10, padx=10)

    def label(self, text="", size=14, color="white"):
        """Tek satırda yazı ekler."""
        lbl = tk.Label(self.root, text=text, font=("Arial", size), fg=color, bg=self.root["bg"])
        lbl.pack(pady=5)

    def popup(self, title="Bilgi", message=""):
        """Tek satırda açılır uyarı penceresi gösterir."""
        messagebox.showinfo(title, message)

    def run(self):
        """Pencereyi başlatır."""
        if self.root:
            self.root.mainloop()

# Tek bir instance
milenium_gui = MileniumWindow()

# Auto-generated instance for Milenium Parser
mwindow = MileniumWindow()
